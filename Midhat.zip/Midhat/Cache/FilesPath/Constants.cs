﻿namespace Cache.FilesPath
{
    public class Constants
    {
        public static string StudentFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\StudentsData.xml";
        public static string TeacherFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\TeachersData.xml";
        public static string UserFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\UsersData.xml";
        public static string AnnouncementFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\AnnouncementData.xml";
        public static string CoursesFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\CoursesData.xml";
        public static string AttendanceFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\AttendanceData.xml";
        public static string ResultFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\ResultData.xml";
        public static string AdmissionFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\AdmissionFile.xml";
        public static string SubjectFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\SubjectData.xml";
        public static string ClassRangeFilePath = @"C:\Users\mhussain\Downloads\App\Midhat\Uitilies\Files\ClassRangeData.xml";
    }
}
