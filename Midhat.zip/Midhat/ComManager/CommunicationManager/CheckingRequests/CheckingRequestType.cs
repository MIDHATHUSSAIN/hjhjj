﻿using Cache.Lists;
using Newtonsoft.Json;
using Repo.Repos;
using Uitilies.Types;

namespace ComManager.CommunicationManager.CheckingRequests
{
    public class CheckingRequestType
    {
        HandleRequests Hr = new HandleRequests();       
        public CheckingRequestType()
        {
            CacheData.LoadingInitialData();
        }
        public string ProcessRequest(string jsonData)
        {
            try
            {
                var request = JsonConvert.DeserializeObject<NetworkRequest>(jsonData);

                UserRole userRole = request.Role;

                switch (request.Type)
                {
                    case RequestType.SignUp:
                        var signUpData = JsonConvert.DeserializeObject<User>(request.Payload);
                        return Hr.HandleSignupRequest(signUpData);

                    case RequestType.SignIn:
                        var signInData = JsonConvert.DeserializeObject<User>(request.Payload);

                        return Hr.HandleSigninRequest(signInData);
                }

                switch (request.Role)
                {
                    case UserRole.Admin:
                        return Hr.HandleAdminRequest(request);

                    case UserRole.Teacher:
                        return Hr.HandleTeacherRequest(request);

                    case UserRole.Student:
                        return Hr.HandleStudentRequest(request);

                    default:
                        return "Role Not Recognized";
                }
                
            }
            catch (Exception ex)
            {
                return $"Error: {ex.Message}";
            }
        }
    }

    public class NetworkRequest
    {
        public RequestType Type { get; set; } // "SIGNUP" or "LOGIN"

        public UserRole Role { get; set; }
        public string Payload { get; set; } // The actual User object as JSON
    }
}

