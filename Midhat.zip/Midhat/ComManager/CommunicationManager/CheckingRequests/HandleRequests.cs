﻿using Newtonsoft.Json;
using Repo.Repos;
using Server.HandleData.Logics;
using Uitilies.Types;

namespace ComManager.CommunicationManager.CheckingRequests
{
    public class HandleRequests
    {
        SignUpSignInLogic S = new SignUpSignInLogic();
        TeacherLogic Tl = new TeacherLogic();
        StudentLogic Sl = new StudentLogic();
        AnnouncementLogic AL = new AnnouncementLogic();
        CoursesLogic CL = new CoursesLogic();
        AttendanceLogic ATL = new AttendanceLogic();
        ResultLogic RL = new ResultLogic();
        AdmissionLogic ADL = new AdmissionLogic();
        SubjectLogic SL = new SubjectLogic();
        ClassRangeLogic  CRL = new ClassRangeLogic();
        public string HandleSignupRequest(User UserData)
        {
            return S.SigningUp(UserData);
        }

        public string HandleSigninRequest(User UserData)
        {
            return S.SigningIn(UserData);
        }
        public string HandleAdminRequest(NetworkRequest request)
        {
            switch (request.Type)
            {
                case RequestType.AddTeacher:
                    {
                        var teacher = JsonConvert.DeserializeObject<Teacher>(request.Payload);
                        return JsonConvert.SerializeObject(Tl.AddTeacher(teacher));
                    }

                case RequestType.DeleteTeacher:
                    {
                        var teacher = JsonConvert.DeserializeObject<Teacher>(request.Payload);
                        return JsonConvert.SerializeObject(Tl.DeletingTeacher(teacher));
                    }
                case RequestType.UpdateTeacher:
                    {
                        var teacher = JsonConvert.DeserializeObject<Teacher>(request.Payload);
                        return JsonConvert.SerializeObject(Tl.UpdatingTeacher(teacher));
                    }
                case RequestType.RetrievingTeacher:
                    {
                        var teachers = Tl.FethcingTeacher();
                        return JsonConvert.SerializeObject(teachers);
                    }
                case RequestType.AddStudent:
                    {
                        var studentData = JsonConvert.DeserializeObject<Student>(request.Payload);
                        return JsonConvert.SerializeObject(Sl.AddStudent(studentData));

                    }
                case RequestType.DeleteStudent:
                    {
                        var studentData = JsonConvert.DeserializeObject<Student>(request.Payload);
                        return JsonConvert.SerializeObject(Sl.DeletingStudent(studentData)); 
                       
                    }
                case RequestType.UpdateStudent:
                    {
                        var studentData = JsonConvert.DeserializeObject<Student>(request.Payload);
                        return JsonConvert.SerializeObject(Sl.UpdatingStudent(studentData));

                    }
                case RequestType.RetrievingStudent:
                    {
                        var students = Sl.FethcingStudent();
                        return JsonConvert.SerializeObject(students);
                    }
                case RequestType.AddAnnouncement:
                    {
                        var AnnouncementData = JsonConvert.DeserializeObject<Announcement>(request.Payload);
                        return JsonConvert.SerializeObject(AL.AddAnnouncement(AnnouncementData));

                    }
                case RequestType.DeleteAnnouncement:
                    {
                        var AnnouncementData = JsonConvert.DeserializeObject<Announcement>(request.Payload);
                        return JsonConvert.SerializeObject(AL.DeletingAnnouncement(AnnouncementData));

                    }
                case RequestType.UpdateAnnouncement:
                    {
                        var AnnouncementData = JsonConvert.DeserializeObject<Announcement>(request.Payload);
                        return JsonConvert.SerializeObject(AL.UpdatingAnnouncement(AnnouncementData));

                    }
                case RequestType.RetrievingAnnouncement:
                    {
                        var AnnouncementData = AL.FethcingAnnouncement();
                        return JsonConvert.SerializeObject(AnnouncementData);
                    }
                case RequestType.AddCourses:
                    {
                        var CourseData = JsonConvert.DeserializeObject<Courses>(request.Payload);
                        return JsonConvert.SerializeObject(CL.AddCourse(CourseData));

                    }
                case RequestType.UpdateCourses:
                    {
                        var CourseData = JsonConvert.DeserializeObject<Courses>(request.Payload);
                        return JsonConvert.SerializeObject(CL.UpdatingCourse(CourseData));

                    }
                case RequestType.DeleteCourses:
                    {
                        var CourseData = JsonConvert.DeserializeObject<Courses>(request.Payload);
                        return JsonConvert.SerializeObject(CL.DeletingCourse(CourseData));

                    }
                case RequestType.RetrievingCourses:
                    {
                        var CourseData = CL.FethcingCourses();
                        return JsonConvert.SerializeObject(CourseData);
                    }
                case RequestType.AddSubject:
                    {
                        var SubjectData = JsonConvert.DeserializeObject<Subject>(request.Payload);
                        return JsonConvert.SerializeObject(SL.AddSubject(SubjectData));

                    }
                case RequestType.DeleteSubject:
                    {
                        try
                        {
                            var SubjectData = request.Payload;
                            return JsonConvert.SerializeObject(SL.DeletingSubject());

                        }
                        catch(Exception ex)
                        {
                            return ex.Message;
                        }



                    }
                case RequestType.RetrievingSubject:
                    {
                        
                      return JsonConvert.SerializeObject(SL.FethcingSubjects());
                       

                    }
                case RequestType.UpdateSubject:
                    {
                        var SubjectData = JsonConvert.DeserializeObject<Subject>(request.Payload);
                        return JsonConvert.SerializeObject(SL.UpdatingSubject(SubjectData));

                    }
                case RequestType.AddRange:
                    {
                        var ClassRangeData = JsonConvert.DeserializeObject<ClassRange>(request.Payload);
                        return JsonConvert.SerializeObject(CRL.AddClassRange(ClassRangeData));

                    }
                case RequestType.DeleteRange:
                    {
                        var ClassRangeData = JsonConvert.DeserializeObject<ClassRange>(request.Payload);
                        return JsonConvert.SerializeObject(CRL.DeletingClassRange(ClassRangeData));


                    }
                case RequestType.RetrievingRange:
                    {

                        return JsonConvert.SerializeObject(CRL.FethcingClassRange());


                    }
                case RequestType.UpdateRange:
                    {
                        var ClassRangeData = JsonConvert.DeserializeObject<ClassRange>(request.Payload);
                        return JsonConvert.SerializeObject(CRL.UpdatingClassRange(ClassRangeData));

                    }
                default:
                    return "Admin: Action not supported";
            }
        }

        public string HandleTeacherRequest(NetworkRequest request)
        {
            switch (request.Type)
            {
                case RequestType.RetrievingRange:
                    {

                        return JsonConvert.SerializeObject(CRL.FethcingClassRange());


                    }
                case RequestType.RetrievingSubject:
                    {

                        return JsonConvert.SerializeObject(SL.FethcingSubjects());


                    }
                case RequestType.RetrievingTeacher:
                    {
                        var teachers = Tl.FethcingTeacher();
                        return JsonConvert.SerializeObject(teachers);
                    }
                case RequestType.RetrievingStudent:
                    {
                        var students = Sl.FethcingStudent();
                        return JsonConvert.SerializeObject(students);
                    }
                case RequestType.RetrievingAddmission:
                    {
                        return JsonConvert.SerializeObject(ADL.FetchingAdmission());

                    }
                case RequestType.AddAttendance:
                {
                var AttendanceData = JsonConvert.DeserializeObject<Attendance>(request.Payload);
               
                        return JsonConvert.SerializeObject(ATL.AddAttendance(AttendanceData));
                    }
                case RequestType.DeleteAttendance:
                {
                    var AttendanceData = JsonConvert.DeserializeObject<Attendance>(request.Payload);
                     
                    return JsonConvert.SerializeObject(ATL.DeletingAttendance(AttendanceData));

                    }
               case RequestType.UpdateAttendance:
                {
                    var AttendanceData = JsonConvert.DeserializeObject<Attendance>(request.Payload);
                    return JsonConvert.SerializeObject(ATL.UpdatingAttendance(AttendanceData)); 

                }
            case RequestType.RetrievingAttendance:
                {
                    return JsonConvert.SerializeObject(ATL.FethcingAttendance());
                }
             case RequestType.AddResult:
              {
                  var ResultData = JsonConvert.DeserializeObject<Result>(request.Payload);
                   return JsonConvert.SerializeObject(RL.AddResult(ResultData)); 

               }
             case RequestType.DeleteResult:
              {
                 var ResultData = JsonConvert.DeserializeObject<Result>(request.Payload);
                 return JsonConvert.SerializeObject(RL.DeletingResult(ResultData));

              }
             case RequestType.UpdateResult:
              {
                  var ResultData = JsonConvert.DeserializeObject<Result>(request.Payload);
                  return JsonConvert.SerializeObject(RL.UpdatingResult(ResultData));

              }
             case RequestType.RetrievingResult:
                    {
                        
                        return JsonConvert.SerializeObject(RL.FethcingResult());
                    }
                case RequestType.RetrievingAnnouncement:
                    {
                        var AnnouncementData = AL.FethcingAnnouncement();
                        return JsonConvert.SerializeObject(AnnouncementData);
                    }
                default:
               return "Teacher: Action not supported";
            }
        }
        public string HandleStudentRequest(NetworkRequest request)
        {
            switch (request.Type)
            {
                case RequestType.RetrievingTeacher:
                    {
                        var teachers = Tl.FethcingTeacher();
                        return JsonConvert.SerializeObject(teachers);
                    }
                case RequestType.RetrievingStudent:
                    {
                        var students = Sl.FethcingStudent();
                        return JsonConvert.SerializeObject(students);
                    }
                case RequestType.RetrievingAnnouncement:
                    {
                        return JsonConvert.SerializeObject(AL.FethcingAnnouncement());
                    }
                case RequestType.RetrievingAddmission:
                    {
                        return JsonConvert.SerializeObject(ADL.FetchingAdmission());

                    }
                case RequestType.RetrievingResult:
                    {
                        return JsonConvert.SerializeObject(RL.FethcingResult());
                    }
                case RequestType.RetrievingAttendance:
                    {
                        return JsonConvert.SerializeObject(ATL.FethcingAttendance());
                    }
                case RequestType.RetrievingCourses:
                    {
                        return JsonConvert.SerializeObject(CL.FethcingCourses());
                    }
                default:
                    return "Student: Action not supported";
            }
        }
    }
}
