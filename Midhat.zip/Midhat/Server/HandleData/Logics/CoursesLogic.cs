﻿using Cache.Lists;
using Repo.Repos;
using System.Collections.ObjectModel;

namespace Server.HandleData.Logics
{
    public class CoursesLogic
    {
        public ObservableCollection<Courses> AddCourse(Courses CourseData)
        {
            var course = CacheData.Courses.Where(x => x.ClassName == CourseData.ClassName).FirstOrDefault();
            if (course != null)
            {
                Console.WriteLine("Course with this Class Name already exists.");
                return CacheData.Courses;
            }

            CacheData.Courses.Add(CourseData);

            return CacheData.Courses;

        }

        public ObservableCollection<Courses> DeletingCourse(Courses CourseData)
        {

            var course = CacheData.Courses.Where(x => x.ClassName == CourseData.ClassName).FirstOrDefault();
            if (course != null)
            {
                CacheData.Courses.Remove(course);
               

            }
            return CacheData.Courses; ;

        }
        public ObservableCollection<Courses> UpdatingCourse(Courses CourseData)
        {
            var course = CacheData.Courses
                .FirstOrDefault(x => x.ClassName == CourseData.ClassName);

            if (course != null)
            {
                course.Subjects = CourseData.Subjects;
            }

            return CacheData.Courses;
        }
        public ObservableCollection<Courses> FethcingCourses()
        {
            return CacheData.Courses;
        }
    }
}
