﻿using System.Collections.ObjectModel;
using Cache.Lists;
using Repo.Repos;

namespace Server.HandleData.Logics
{
    public class TeacherLogic
    {
      
        public ObservableCollection<Teacher> AddTeacher(Teacher TeacherData)
        {
            var teacher = CacheData.Teachers.Where(x => x.TeacherEmail == TeacherData.TeacherEmail).FirstOrDefault();
            if (teacher != null)
            {
                Console.WriteLine("Teacher with this email already exists.");
                return CacheData.Teachers;
            }

            CacheData.Teachers.Add(TeacherData);

            return CacheData.Teachers;

        }

        public ObservableCollection<Teacher> DeletingTeacher(Teacher TeacherData)
        {
            var teacher = CacheData.Teachers.Where(x => x.TeacherEmail == TeacherData.TeacherEmail).FirstOrDefault();
            if (teacher != null)
            {
                CacheData.Teachers.Remove(teacher);
          

            }
            return CacheData.Teachers;

        }

        public ObservableCollection<Teacher> UpdatingTeacher(Teacher TeacherData)
        {
            var teacher = CacheData.Teachers.Where(x => x.TeacherEmail == TeacherData.TeacherEmail).FirstOrDefault();
            if(teacher != null)
            {
                teacher.TeacherName = TeacherData.TeacherName;
                teacher.TeacherFatherName = TeacherData.TeacherFatherName;
                teacher.TeacherPhone = TeacherData.TeacherPhone;
                teacher.TeacherSalary = TeacherData.TeacherSalary;
                teacher.TeacherSubject = TeacherData.TeacherSubject;
                teacher.TeacherClass = TeacherData.TeacherClass;
                teacher.TeacherExperience = TeacherData.TeacherExperience;
                teacher.TeacherDateofJoining = TeacherData.TeacherDateofJoining;
               
            }
            return CacheData.Teachers;

        }
        public ObservableCollection<Teacher> FethcingTeacher()
        {
            return CacheData.Teachers;
        }
    }
}
