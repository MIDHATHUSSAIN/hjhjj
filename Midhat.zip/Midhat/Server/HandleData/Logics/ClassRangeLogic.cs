﻿using System.Collections.ObjectModel;
using Cache.Lists;
using Repo.Repos;

namespace Server.HandleData.Logics
{
    public class ClassRangeLogic
    {
        public ObservableCollection<ClassRange> AddClassRange(ClassRange ClassData)
        { 
            if (ClassData.StartingFrom == null || ClassData.EndingAt ==null)
            {
                return CacheData.ClassRanges;
            }

            CacheData.ClassRanges.Clear();
            CacheData.ClassRanges.Add(ClassData);

            return CacheData.ClassRanges;

        }

        public ObservableCollection<ClassRange> DeletingClassRange(ClassRange ClassData)
        {

            var classRange = CacheData.ClassRanges.Where(x => x.StartingFrom == ClassData.StartingFrom && x.EndingAt == ClassData.EndingAt).FirstOrDefault();
            if (classRange != null)
            {
                CacheData.ClassRanges.Remove(classRange);


            }
            return CacheData.ClassRanges; 

        }
        public ObservableCollection<ClassRange> UpdatingClassRange(ClassRange ClassData)
        {
            var classRange = CacheData.ClassRanges
                .FirstOrDefault(x => x.StartingFrom == ClassData.StartingFrom && x.EndingAt == ClassData.EndingAt);

            if (classRange != null)
            {
                classRange.StartingFrom = ClassData.StartingFrom;
                classRange.EndingAt = ClassData.EndingAt;
            }

            return CacheData.ClassRanges;
        }
        public ObservableCollection<ClassRange> FethcingClassRange()
        {
            return CacheData.ClassRanges;
        }
    }
}
