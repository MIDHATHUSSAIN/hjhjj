﻿using Cache.Lists;
using Repo.Repos;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.HandleData.Logics
{
    public class ResultLogic
    {
        public ObservableCollection<Result> AddResult(Result ResultData)
        {
            CacheData.Results.Add(ResultData);

            return CacheData.Results;

        }

        public ObservableCollection<Result> DeletingResult(Result ResultData)
        {

            var result = CacheData.Results.Where(x => x.email == ResultData.email).FirstOrDefault(); 
            if (result != null)
            {
                CacheData.Results.Remove(result);
               

            }
            return CacheData.Results;

        }
        public ObservableCollection<Result> UpdatingResult(Result ResultData)
        {
            var result = CacheData.Results.Where(x => x.email == ResultData.email).FirstOrDefault();
            if (result != null)
            {
                result.Name = ResultData.Name;
                result.email = ResultData.email;
                result.SubjectName = ResultData.SubjectName;
                result.className = ResultData.className;
                result.TotalMarks = ResultData.TotalMarks;
                result.Marks = ResultData.Marks;
                
            }

            return CacheData.Results;
        }
        public ObservableCollection<Result> FethcingResult()
        {
            return CacheData.Results;
        }
    }
}
