﻿using System.Collections.ObjectModel;
using Cache.Lists;
using Repo.Repos;

namespace Server.HandleData.Logics
{
    public class SubjectLogic
    {
        public ObservableCollection<Subject> AddSubject(Subject SubjectData)
        {
            var subject = CacheData.Subjects.Where(x => x.SubjectName == SubjectData.SubjectName).FirstOrDefault();
            if (subject != null)
            {
                return CacheData.Subjects;
            }

            CacheData.Subjects.Add(SubjectData);

            return CacheData.Subjects;

        }

        public ObservableCollection<Subject> DeletingSubject()
        {

        
                CacheData.Subjects.Clear();


          
            return CacheData.Subjects; ;

        }
        public ObservableCollection<Subject> UpdatingSubject(Subject SubjectData)
        {
            var subject = CacheData.Subjects
                .FirstOrDefault(x => x.SubjectName == SubjectData.SubjectName);

            if (subject != null)
            {
                subject.SubjectName = SubjectData.SubjectName;
  
            }

            return CacheData.Subjects;
        }
        public ObservableCollection<Subject> FethcingSubjects()
        {
            return CacheData.Subjects;
        }
    }
}
