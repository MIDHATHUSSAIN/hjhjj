﻿using System.Collections.ObjectModel;
using Cache.Lists;
using Repo.Repos;

namespace Server.HandleData.Logics
{
    public class AttendanceLogic
    {
        public ObservableCollection<Attendance> AddAttendance(Attendance AttendanceData)
        {
            
            CacheData.Attendances.Add(AttendanceData);

            return CacheData.Attendances;

        }

        public ObservableCollection<Attendance> DeletingAttendance(Attendance AttendanceData)
        {

            var attendance = CacheData.Attendances.Where(x => x.email == AttendanceData.email).FirstOrDefault();
            if (attendance != null)
            {
                CacheData.Attendances.Remove(attendance);
                Console.WriteLine("Attendance Deleted Successfully");

            }
          return CacheData.Attendances;
        
        }
        public ObservableCollection<Attendance> UpdatingAttendance(Attendance AttendanceData)
        {
            try
            {

                var attendance = CacheData.Attendances.Where(x => x.email == AttendanceData.email).FirstOrDefault();
                if (attendance != null)
                {

                    attendance.Name = AttendanceData.Name;
                    attendance.email = AttendanceData.email;
                    attendance.Status = AttendanceData.Status;
                    attendance.FatherName = AttendanceData.FatherName;
                    attendance.ClassName = AttendanceData.ClassName;
                    attendance.Date = AttendanceData.Date;

                }

                return CacheData.Attendances;
            }
            catch (Exception ex) {

                return CacheData.Attendances;
            }
            
            
           
        }
        public ObservableCollection<Attendance> FethcingAttendance()
        {
            return CacheData.Attendances;
        }
    }
}
