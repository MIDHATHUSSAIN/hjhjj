﻿namespace Repo.Repos
{
    public class Courses
    {
        public string ClassName { get; set; }

        public List<Subject> Subjects { get; set; } = new List<Subject>();

        public DateTime CreatedAt { get; set; } = DateTime.Now;


        public string SubjectsAndBooksDisplay =>
            Subjects != null && Subjects.Any()
                ? string.Join(", ", Subjects.Select(s => $"{s.SubjectName} ({s.BookName})"))
                : "No Subjects";
    }
}