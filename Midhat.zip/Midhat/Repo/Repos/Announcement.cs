﻿namespace Repo.Repos
{
    public class Announcement
    {
        private int announcementNumber;
        private DateTime announcementDate = DateTime.Now;
        private string title;
        private string annoucement;
        private string forWhom;

        public DateTime AnnouncementDate
        {
            get { return announcementDate; }
            set { announcementDate = value; }
        }

        public int AnnouncementNumber
        {
            get { return announcementNumber; }
            set { announcementNumber = value; }

        }
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Annoucementt
        {
            get { return annoucement; }
            set { annoucement = value; }
        }
        public string ForWhom
        {
            get { return forWhom; }
            set { forWhom = value; }
        }
    }
}
