﻿namespace Repo.Repos
{
    public class Subject
    {   
        public string SubjectName { get; set; }
        public string BookName { get; set; }
    }
}
