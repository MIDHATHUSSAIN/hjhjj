﻿namespace Repo.Repos
{
    public class Admission
    {
        public int StartingYear { get; set; }
        public int EndingYear { get; set; }
    }
}
