﻿namespace Repo.Repos
{
    public class Student
    {
        private DateTime joiningDate = DateTime.Now;
        private string studentFatherName;
        private string studentName;
        private string studentEmail;
        private int studentClass;
        private int studentFee;
        private string studentPhone;
        public DateTime JoiningDate
        {
            get { return joiningDate; }
            set { joiningDate = value; }
        }

        public string StudentName
        {
            get { return studentName; }
            set { studentName = value; }
        }

        public string StudentFatherName
        {
            get { return studentFatherName; }
            set { studentFatherName = value; }
        }
        public string StudentEmail
        {
            get { return studentEmail; }
            set { studentEmail = value; }
        }

        public int StudentClass
        {
            get { return studentClass; }
            set { studentClass = value; }
        }

        public int StudentFee
        {
            get { return studentFee; }
            set { studentFee = value; }
        }

        public string StudentPhone
        {
            get { return studentPhone; }
            set { studentPhone = value; }
        }
    }
}
