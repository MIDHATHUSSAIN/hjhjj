﻿namespace Repo.Repos
{
    public class ClassRange
    {
        public int StartingFrom { get; set; }
        public int EndingAt { get; set; } 
    }
}
