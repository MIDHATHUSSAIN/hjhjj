﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repo.Repos
{
     public class Attendance
    {
        public string Name { get; set; }
        public string email { get; set; }
        public string FatherName { get; set; }
        public string ClassName { get; set; }
        public string Status { get; set; }
        public DateTime Date { get; set; } = DateTime.Now;
    }
}
