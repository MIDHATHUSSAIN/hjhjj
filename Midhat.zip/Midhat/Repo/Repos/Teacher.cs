﻿namespace Repo.Repos
{
    public class Teacher
    {
        private string teacherName;
        private string teacherFatherName;
        private int teacherClass;
        private string teacherSubject;
        private int teacherSalary;
        private string teacherEmail;
        private decimal teacherExperience;
        private DateTime teacherDateofJoining = DateTime.Now;
        private string teacherPhone;


        public string TeacherName
        {
            get { return teacherName; }
            set { teacherName = value; }
        }

        public string TeacherFatherName
        {
            get { return teacherFatherName; }
            set { teacherFatherName = value; }
        }

        public int TeacherClass
        {
            get { return teacherClass; }
            set { teacherClass = value; }
        }

        public string TeacherSubject
        {
            get { return teacherSubject; }
            set { teacherSubject = value; }

        }

        public int TeacherSalary
        {
            get { return teacherSalary; }
            set { teacherSalary = value; }
        }

        public string TeacherEmail
        {
            get { return teacherEmail; }
            set { teacherEmail = value; }
        }

        public decimal TeacherExperience
        {
            get { return teacherExperience; }
            set { teacherExperience = value; }
        }

        public DateTime TeacherDateofJoining
        {
            get { return teacherDateofJoining; }
            set { teacherDateofJoining = value; }
        }

        public string TeacherPhone
        {
            get { return teacherPhone; }
            set { teacherPhone = value; }
        }
    }
}
