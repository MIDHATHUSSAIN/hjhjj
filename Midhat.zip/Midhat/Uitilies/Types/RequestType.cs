﻿namespace Uitilies.Types
{
    public enum RequestType
    {

        SignUp,
        SignIn,
        AddTeacher,
        DeleteTeacher,
        UpdateTeacher,
        RetrievingTeacher,
        AddStudent,
        DeleteStudent,
        UpdateStudent,
        RetrievingStudent,
        AddAnnouncement,
        DeleteAnnouncement,
        UpdateAnnouncement,
        RetrievingAnnouncement,
        AddCourses,
        DeleteCourses,
        UpdateCourses,
        RetrievingCourses,
        AddResult,
        DeleteResult,
        RetrievingResult,
        UpdateResult,
        AddAttendance,
        DeleteAttendance,
        UpdateAttendance,
        RetrievingAttendance,
        ViewSubjects,
        RetrievingAddmission,
        AddRange, DeleteRange,
        UpdateRange,
        RetrievingRange,
        AddSubject,
        DeleteSubject,
        UpdateSubject,
        RetrievingSubject

    }
}
